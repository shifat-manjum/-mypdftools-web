import{a as r}from"./vendor-pdflib-CWhyEUqa.js";import{r as o}from"./vendor-utils-w1iM95Re.js";var i=o();const t=r(i);export{t as J};
