import{r as m}from"./vendor-pdfjs-C1tIVYpA.js";var d=m();const u="/assets/pdf.worker.min-DKQKFyKK.js";if(typeof window<"u")try{d.GlobalWorkerOptions.workerSrc=u||"/pdf.worker.min.js"}catch{d.GlobalWorkerOptions.workerSrc="/pdf.worker.min.js"}async function l(a){const o=await a.arrayBuffer();return await d.getDocument({data:new Uint8Array(o),cMapUrl:"https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/cmaps/",cMapPacked:!0}).promise}async function P(a){return(await l(a)).numPages}function w(a,o){const s=a.split(","),n=atob(s[1]||""),r=new ArrayBuffer(n.length),e=new Uint8Array(r);for(let t=0;t<n.length;t++)e[t]=n.charCodeAt(t);return new Blob([e],{type:o})}async function h(a,o,s=1.5){const n=await a.getPage(o),r=n.getViewport({scale:s}),e=document.createElement("canvas"),t=e.getContext("2d",{willReadFrequently:!0});if(!t)throw new Error("Canvas context not available");return e.width=Math.floor(r.width),e.height=Math.floor(r.height),await n.render({canvasContext:t,viewport:r}).promise,e}async function k(a,o=1.5,s="image/jpeg",n){const r=await l(a),e=r.numPages,t=[],p=s==="image/png"?"image/png":"image/jpeg";for(let i=1;i<=e;i++){const g=await h(r,i,o),c=g.toDataURL(p,.92),f=w(c,p);t.push({pageNumber:i,dataUrl:c,blob:f,width:g.width,height:g.height}),n&&n(i,e)}return t}async function x(a,o){const s=await l(a),n=s.numPages;let r=`# ${a.name.replace(/\.[^/.]+$/,"")}

`,e="";for(let t=1;t<=n;t++){const g=(await(await s.getPage(t)).getTextContent()).items;r+=`## Page ${t}

`;let c="";for(const f of g)c+=f.str+(f.hasEOL?`
`:" ");r+=c.trim()+`

---

`,e+=`--- Page ${t} ---
`+c.trim()+`

`}return{markdown:r.trim(),plainText:e.trim(),pageCount:n}}export{k as c,x as e,P as g,l};
